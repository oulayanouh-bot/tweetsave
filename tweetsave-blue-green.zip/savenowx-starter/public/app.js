const form = document.querySelector("#form");
const input = document.querySelector("#url");
const status = document.querySelector("#status");
const result = document.querySelector("#result");
const formats = document.querySelector("#formats");
const thumb = document.querySelector("#thumb");
const title = document.querySelector("#title");

function size(n) {
  if (!n) return "";
  const units = ["B","KB","MB","GB"];
  let i = 0, x = n;
  while (x >= 1024 && i < units.length - 1) { x /= 1024; i++; }
  return `${x.toFixed(i ? 1 : 0)} ${units[i]}`;
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  result.classList.add("hidden");
  formats.innerHTML = "";
  status.textContent = "Checking the post…";

  try {
    const r = await fetch("/api/info", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({url: input.value.trim()})
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Something went wrong.");

    status.textContent = "";
    title.textContent = data.title || "X video";
    if (data.thumbnail) {
      thumb.src = data.thumbnail;
      thumb.style.display = "block";
    } else thumb.style.display = "none";

    const videoFormats = data.formats.filter(f => f.vcodec !== "none");
    if (!videoFormats.length) throw new Error("No downloadable video format was found.");

    videoFormats.sort((a,b) => (b.height||0) - (a.height||0));
    for (const f of videoFormats) {
      const label = `${f.height ? f.height + "p" : f.ext.toUpperCase()}${f.fps ? " · " + Math.round(f.fps) + "fps" : ""}`;
      const el = document.createElement("div");
      el.className = "format";
      el.innerHTML = `<strong>${label}<br><small>${f.ext.toUpperCase()}${f.filesize ? " · " + size(f.filesize) : ""}</small></strong>
        <a href="${f.url}" target="_blank" rel="noopener">Save</a>`;
      formats.appendChild(el);
    }
    result.classList.remove("hidden");
  } catch (err) {
    status.textContent = err.message;
  }
});