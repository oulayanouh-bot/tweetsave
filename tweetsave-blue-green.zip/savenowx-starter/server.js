const express = require("express");
const path = require("path");
const { spawn } = require("child_process");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function validXUrl(value) {
  try {
    const u = new URL(value);
    return ["x.com", "twitter.com", "mobile.twitter.com"].includes(u.hostname);
  } catch {
    return false;
  }
}

app.post("/api/info", (req, res) => {
  const { url } = req.body || {};
  if (!validXUrl(url)) {
    return res.status(400).json({ error: "Please enter a valid public X post URL." });
  }

  const args = ["--dump-single-json", "--no-playlist", "--no-warnings", url];
  const child = spawn("yt-dlp", args);
  let out = "", err = "";

  child.stdout.on("data", d => out += d);
  child.stderr.on("data", d => err += d);

  child.on("error", () => {
    res.status(500).json({
      error: "yt-dlp is not installed on the server. Install yt-dlp and try again."
    });
  });

  child.on("close", code => {
    if (code !== 0) {
      return res.status(422).json({
        error: "Could not read this post. It may be private, unavailable, or unsupported."
      });
    }

    try {
      const data = JSON.parse(out);
      const formats = (data.formats || [])
        .filter(f => f.url && (f.vcodec !== "none" || f.acodec !== "none"))
        .map(f => ({
          id: f.format_id,
          ext: f.ext,
          width: f.width,
          height: f.height,
          fps: f.fps,
          filesize: f.filesize || f.filesize_approx || null,
          vcodec: f.vcodec,
          acodec: f.acodec,
          url: f.url
        }));

      res.json({
        title: data.title || "X video",
        thumbnail: data.thumbnail || null,
        formats
      });
    } catch {
      res.status(500).json({ error: "Invalid extractor response." });
    }
  });
});

app.listen(PORT, () => {
  console.log(`SaveNowX starter running at http://localhost:${PORT}`);
});