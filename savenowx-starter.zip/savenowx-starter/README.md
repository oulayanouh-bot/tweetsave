# SaveNowX starter

A clean starter inspired by the supplied SaveNowX promotional design.

## Run locally

1. Install Node.js 18+.
2. Install `yt-dlp` and make sure the `yt-dlp` command is available in your PATH.
3. Run:

```bash
npm install
npm start
```

Open `http://localhost:3000`.

### Optional: FFmpeg

Install FFmpeg if you later want server-side format merging or MP3 conversion.

## Important

This starter is intended for public posts and content you are authorized to download. Platform terms, copyright, privacy, and local laws still apply. The exact media formats returned can change as the platform changes.